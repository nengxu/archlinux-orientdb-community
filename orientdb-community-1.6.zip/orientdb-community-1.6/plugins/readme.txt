This is the folder to copy plugins. Plugins can be in the form of:
- ZIP file
- JAR file
- directory
